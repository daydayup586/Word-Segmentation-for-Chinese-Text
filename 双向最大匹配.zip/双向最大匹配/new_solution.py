import codecs
import xlrd


# 正向最大匹配
class MM(object):
    def __init__(self, words_dic):
        self.dictionary = set()
        self.maximum = 0

        for line in words_dic:
            line = line.strip()
            if not line:
                continue
            self.dictionary.add(line)
            if len(line) > self.maximum:
                self.maximum = len(line)

    def cut(self, text):
        result = []
        size = self.maximum
        text_len = len(text)
        while text_len > 0:
            word = text[0:size]
            while word not in self.dictionary:
                if len(word) == 1:
                    break
                word = word[0:len(word) - 1]
            result.append(word)
            text = text[len(word):]
            text_len = len(text)
        return result


# 逆向最大匹配
class IMM(object):
    def __init__(self, words_dic):
        self.dictionary = set()
        self.maximum = 0

        for line in words_dic:
            line = line.strip()
            if not line:
                continue
            self.dictionary.add(line)
            if len(line) > self.maximum:
                self.maximum = len(line)

    def cut(self, text):
        result = []
        index = len(text)
        while index > 0:
            word = None
            for size in range(self.maximum, 0, -1):
                if index - size < 0:
                    continue
                piece = text[(index - size):index]
                if piece in self.dictionary:
                    word = piece
                    result.append(word)
                    index -= size
                    break
            if word is None:
                index -= 1
        return result[::-1]


def read_dic(dic_path):
    excel = xlrd.open_workbook(dic_path)
    sheet = excel.sheets()[0]  # 读取第二列的数据
    data_list = list(sheet.col_values(1))[1:]
    return data_list


def doubleMax(text, words_dic):
    left = MM(words_dic)
    right = IMM(words_dic)

    leftMatch = left.cut(text)
    rightMatch = right.cut(text)

    # 返回分词数较少者
    if (len(leftMatch) != len(rightMatch)):
        if (len(leftMatch) < len(rightMatch)):
            return leftMatch
        else:
            return rightMatch
    else:  # 若分词数量相同，进一步判断
        leftsingle = 0
        rightsingle = 0
        isEqual = True  # 用以标志结果是否相同
        for i in range(len(leftMatch)):
            if (leftMatch[i] != rightMatch[i]):
                isEqual = False
            # 统计单字数
            if (len(leftMatch[i]) == 1):
                leftsingle += 1
            if (len(rightMatch[i]) == 1):
                rightsingle += 1
        if (isEqual):
            return leftMatch
        if (leftsingle < rightsingle):
            return leftMatch
        else:
            return rightMatch


def outfile(out_path, sentences):
    # 输出模式是“a”即在原始文本上继续追加文本
    with codecs.open(out_path, "a", "utf8") as f:
        for sentence in sentences:
            f.write(sentence)
    print("well done!")


if __name__ == '__main__':
    rawfile_path = "分词文本.txt"
    t = codecs.open(rawfile_path,'r',encoding='UTF-8')
    text = t.read()
    wordfile_path = "words.xlsx"  # 读取分词词典
    words_dic = read_dic(wordfile_path)
    # text="我来自上海。"
    Match = doubleMax(text, words_dic)
    words = "/".join(Match)
    outfile_path = r"分词结果.txt"  # 输出文本
    outfile(outfile_path, words)

