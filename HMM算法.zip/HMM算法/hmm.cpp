#include<fstream>
#include<iostream>
#include<vector>
#include<set>
#include<map>
#include <string>
#include<locale>
#include <Windows.h>
#include <codecvt>
using namespace std;
std::wstring_convert<std::codecvt_utf8<wchar_t>> conv;
int STATES[4] = { 0,1,2,3 };   //['B', 'M', 'E', 'S']

double array_a[4][4] = { 0 };

map<wchar_t, double> array_b[4];

double array_pi[4] = { 0 };

set<wchar_t> word_set;

double count_dic[4] = { 0 };

double line_num = 0;





wstring get_tag(wstring word) {
    wstring tag = L"";
    if (word.length() == 1)
        tag = L"3";
    else if (word.length() == 2)
        tag = L"02";
    else {
        int num = word.length() - 2;
        tag += L"0";
        for (int i = 0; i < num; i++) {
            tag += L"1";
        }
        tag += L"2";
    }

    return tag;
}

void prob_Array() {
    for (int i = 0; i < 4; i++) {
        if (array_pi[i] == 0) {
            array_pi[i] = -3.14e+100;
        }
        else
            array_pi[i] = log(array_pi[i] / line_num);
    }

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (array_a[i][j] == 0)
                array_a[i][j] = -3.14e+100;
            else
                array_a[i][j] = log(array_a[i][j] / count_dic[i]);
        }
    }
    for (int j = 0; j < 4; j++) {
        for (auto i = array_b[j].begin(); i != array_b[j].end(); ++i) {
            if (i->second == 0) {
                i->second = -3.14e+100;
            }
            else
                i->second = log(i->second / count_dic[j]);
        }
    }
}

vector<wstring> seg_tag(wstring sentence, wstring tag) {
    vector<wstring> word_list;
    int start = 0;
    int started = 0; //False
    if (sentence.length() != tag.length()) {
        cout << "�ַ������Ȳ�ƥ��" << endl;
        return word_list;
    }
    if (sentence.length() == 1) {
        word_list.push_back(sentence);
    }
    else {
        int length = tag.length();
        if (tag[length - 1] == '0' || tag[length - 1] == '1') {
            if (tag[length - 2] == '0' || tag[length - 2] == '1') {
                tag[length - 1] = '3';
            }
            else
                tag[length - 1] = '2';
        }

        for (int i = 0; i < length; i++) {
            if (tag[i] == '3') {
                if (started) {
                    started = 0;
                    wstring str(sentence, start, i - start );
                    word_list.push_back(str);
                }
                wstring str=L"";
                str += sentence[i];
                word_list.push_back(str);
            }
            else if (tag[i] == '0') {
                if (started) {

                    wstring str(sentence, start, i - start );
                    word_list.push_back(str);
                }
                start = i;
                started = 1;
            }
            else if (tag[i] == '2') {
                started = 0;

                wstring str(sentence, start, i - start + 1);
                word_list.push_back(str);


            }
            else if (tag[i] == '1')
                continue;
        }

    }
    return word_list;
}




string UTF8ToGB(const char* str)  //������UTF-8תGB�������������
{
    string result;
    WCHAR* strSrc;
    LPSTR szRes;

    //�����ʱ�����Ĵ�С
    int i = MultiByteToWideChar(CP_UTF8, 0, str, -1, NULL, 0);
    strSrc = new WCHAR[i + 1];
    MultiByteToWideChar(CP_UTF8, 0, str, -1, strSrc, i);

    //�����ʱ�����Ĵ�С
    i = WideCharToMultiByte(CP_ACP, 0, strSrc, -1, NULL, 0, NULL, NULL);
    szRes = new CHAR[i + 1];
    WideCharToMultiByte(CP_ACP, 0, strSrc, -1, szRes, i, NULL, NULL);

    result = szRes;
    delete[]strSrc;
    delete[]szRes;

    return result;
}

wstring Viterbi(wstring sentence,double array_PI[],double array_A[][4], map<wchar_t, double> array_B[]) {
    vector<double> tab[4];
    wstring path[4];
    double prob;
    for (int i = 0; i < 4; i++) {
        path[i] = L"";
    }

    map<wchar_t, double>::iterator it = array_B[0].find(sentence[0]);
    if (it != array_B[0].end()) {
        //printf("%c %d\n", it->first, it->second);
    }
    else {
        for (int i = 0; i < 4; i++) {
            if (i == 3) {
                array_B[i][sentence[0]] = 0;
            }
            else {
                array_B[i][sentence[0]] = -3.14e+100;
            }
        }
    }
    for (int i = 0; i < 4; i++) {
        double score = array_PI[i] + array_B[i][sentence[0]];
        tab[i].push_back(score);
        if (i == 0)
            path[i] += L"0";
        else if (i == 1)
            path[i] += L"1";
        else if (i == 2)
            path[i] += L"2";
        else if (i == 3)
            path[i] += L"3";
    }
    for (unsigned int i = 1; i < sentence.length(); i++) {
        
        wstring new_path[4];
        for (int j = 0; j < 4; j++) {
            new_path[j] = L"";
        }
        for (int j = 0; j < 4; j++) {
            if (j == 0) {
                array_B[j][L'B'] = 0;
            }
            else {
                array_B[j][L'B'] = -3.14e+100;
            }
        }
        for (int j = 0; j < 4; j++) {
            if (j == 3) {
                array_B[j][L'E'] = 0;
            }
            else {
                array_B[j][L'E'] = -3.14e+100;
            }
        }
        
        for (int j = 0; j < 4; j++) {
            vector<double> items;
            /// <summary>
            /// /////////////
            /// </summary>
            /// <param name="sentence"></param>
            /// <param name="array_PI"></param>
            /// <param name="array_A"></param>
            /// <param name="array_B"></param>
            /// <returns></returns>
            for (int k = 0; k < 4; k++) {
                
                it = array_B[j].find(sentence[i]);
                if (it != array_B[j].end()) {
                    //cout << k << "***" << endl;
                    //printf("%c %d\n", it->first, it->second);
                    prob = tab[k][i - 1] + array_A[k][j] + array_B[j][sentence[i]];
                    
                }
                else {
                    //cout << k << "haha+++" << endl;
                    map<wchar_t, double>::iterator it_new = array_B[j].find(sentence[i-1]);
                    if (it_new != array_B[j].end()) {
                        //printf("%c %d\n", it->first, it->second);
                        prob = tab[k][i - 1] + array_A[k][j] + array_B[j]['B'];
                    }
                    else {
                        prob = tab[k][i - 1] + array_A[k][j] + array_B[j]['E'];
                    }
                }
                items.push_back(prob);
                //wcout << prob << "---" << endl;
            }
            //cout << j << "***" << endl;
            /// <summary>
            /// ///////////////////
            /// </summary>
            /// <param name="sentence"></param>
            /// <param name="array_PI"></param>
            /// <param name="array_A"></param>
            /// <param name="array_B"></param>
            /// <returns></returns>
            int best;
            double max = -3.14e+305;
            for (int k = 0; k < 4; k++) {
                if (items[k] > max) {
                    max = items[k];
                    best = k;
                }
            }

            tab[j].push_back(items[best]);
            if (j == 0)
                new_path[j] = path[best] + L'0';
            else if (j == 1)
                new_path[j] = path[best] + L'1';
            else if (j == 2)
                new_path[j] = path[best] + L'2'; 
            else if (j == 3)
                new_path[j] = path[best] + L'3';
        }
        for (int j = 0; j < 4; j++) {
            path[j] = new_path[j];
        }
        
    }

    double mmax = -3.14e+305;
    int STA;
    for (int i = 0; i < 4; i++) {

        if (tab[i][sentence.length() - 1] > mmax) {
            mmax = tab[i][sentence.length() - 1];
            STA = i;
        }
    }

    

    return path[STA];

}

inline std::string to_byte_string(const std::wstring& input)
{
    //std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
    std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
    return converter.to_bytes(input);
}


int main() {
    wcout.imbue(locale("chs"));			//������������ ֻΪ����̨�����ʾ
    std::ifstream testset(L"test.txt");
    std::ifstream trainset(L"CTBtrainingset.txt");
    std::ofstream outset("out.txt");
    while (!trainset.eof())
    {
        
        string line;
        getline(trainset, line);
        wstring wb = conv.from_bytes(line);
        line_num += 1;
        vector<wchar_t> word_list;
        for (unsigned int i = 0; i < wb.length(); i++) {
            if (wb[i] == ' ')
                continue;
            word_list.push_back(wb[i]);
        }
        for (unsigned int i = 0; i < wb.length(); i++) {
            word_set.insert(wb[i]);
        }
        

        vector<wstring> lines;
        wstring L = L"";
        for (unsigned int i = 0; i < wb.length(); i++) {
            
            if (wb[i] != ' ')
                L += wb[i];
            else {
                lines.push_back(L);
                L = L"";
            }
        }
        vector<int> line_state;
        wstring wline_state = L"";
        for (unsigned int i = 0; i < lines.size(); i++) {
            //wcout << lines[i] << endl;
            wline_state += get_tag(lines[i]);
        }
        
        //wcout << wline_state << endl;
        for (unsigned int i = 0; i < wline_state.length(); i++) {
            if (wline_state[i] == L'0') {
                line_state.push_back(0);
            }
            else if (wline_state[i] == L'1') {
                line_state.push_back(1);
            }
            else if (wline_state[i] == L'2') {
                line_state.push_back(2);
            }
            else if (wline_state[i] == L'3') {
                line_state.push_back(3);
            }
        }
        array_pi[line_state[0]] += 1;

        for (unsigned int i = 0; i < line_state.size()-1; i++) {
            array_a[line_state[i]][line_state[i + 1]] += 1;
        }
        for (unsigned int i = 0; i < line_state.size(); i++) {
            count_dic[line_state[i]] += 1;
            for (int j = 0; j < 4; j++) {
                map<wchar_t, double>::iterator it = array_b[j].find(word_list[i]);
                if (it != array_b[j].end()) {
                    //printf("%c %d\n", it->first, it->second);
                }
                else {
                    array_b[j][word_list[i]] = 0;
                    //printf("û�ҵ�\n");
                }

            }
            array_b[line_state[i]][word_list[i]] += 1;

            //wcout << line_state[i] << "   " << word_list[i] << endl;

        }
        
        

       // wcout << "**********************************************************" << endl;
        //wcout << wb << endl;
    }
    prob_Array();

    /*for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << array_a[i][j] << ' ';
        }
        cout << endl;
    }*/
    wstring output = L"";

    
    while (!testset.eof()){
        

        string ss;
        getline(testset, ss);
        
        if (int(ss[0]) == 0)
            continue;
        wstring old_line = conv.from_bytes(ss);
        wstring line = L"";
        

        for (unsigned int i = 0; i < old_line.length(); i++) {
            if (old_line[i] != ' ') {
                line += old_line[i];
            }
        }
        wstring tag;
        tag = Viterbi(line, array_pi, array_a, array_b);
        
        //wcout << tag << endl;
        vector<wstring> seg;
        seg = seg_tag(line, tag);
        //cout << tag.length() << "   " << line.length();
        wstring list = L"";
        for (unsigned int i = 0; i < seg.size(); i++) {
            list = list + L'\\' + seg[i];
        }

        output = output + list + L'\n';
    }

    string out = to_byte_string(output);
    outset << out;
    //wcout << output;
    
    outset.close();
    trainset.close();
    testset.close();
}